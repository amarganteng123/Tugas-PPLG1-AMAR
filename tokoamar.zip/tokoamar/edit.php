<?php
include 'config.php';

$id = $_GET['id'];
$result = mysqli_query($conn, "SELECT * FROM barangg WHERE id=$id");
$data = mysqli_fetch_assoc($result);

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nama = htmlspecialchars($_POST['nama_barang']);
    $harga = $_POST['harga'];
    $stok = $_POST['stok'];

    $query = "UPDATE barangg SET nama_barang='$nama', harga='$harga', stok='$stok' WHERE id=$id";
    if (mysqli_query($conn, $query)) {
        header("Location: index.php");
    } else {
        echo "Gagal mengedit data!";
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Barang</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

    <h2>Edit Barang</h2>
    <form method="POST">
        <label>Nama Barang:</label><br>
        <input type="text" name="nama_barang" value="<?= $data['nama_barang'] ?>" required><br><br>

        <label>Harga:</label><br>
        <input type="number" name="harga" value="<?= $data['harga'] ?>" required><br><br>

        <label>Stok:</label><br>
        <input type="number" name="stok" value="<?= $data['stok'] ?>" required><br><br>

        <button type="submit">Simpan Perubahan</button>
    </form>

</body>
</html>