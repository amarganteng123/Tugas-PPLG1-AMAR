<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "jadwal_pelajaran";

// Koneksi ke database
$conn = new mysqli($servername, $username, $password, $dbname);

// Cek koneksi
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

// Buat tabel jika belum ada
$sql = "CREATE TABLE IF NOT EXISTS jadwal (
    id INT AUTO_INCREMENT PRIMARY KEY,
    hari VARCHAR(20) NOT NULL,
    mata_pelajaran VARCHAR(50) NOT NULL,
    jam_mulai TIME NOT NULL,
    jam_selesai TIME NOT NULL,
    guru VARCHAR(50) NOT NULL
)";
$conn->query($sql);

// Tambah data
if (isset($_POST['tambah'])) {
    $hari = $_POST['hari'];
    $mata_pelajaran = $_POST['mata_pelajaran'];
    $jam_mulai = $_POST['jam_mulai'];
    $jam_selesai = $_POST['jam_selesai'];
    $guru = $_POST['guru'];
    
    $sql = "INSERT INTO jadwal (hari, mata_pelajaran, jam_mulai, jam_selesai, guru) 
            VALUES ('$hari', '$mata_pelajaran', '$jam_mulai', '$jam_selesai', '$guru')";
    $conn->query($sql);
}

// Hapus data
if (isset($_GET['hapus'])) {
    $no = $_GET['hapus'];
    $sql = "DELETE FROM jadwal WHERE no='$no'";
    $conn->query($sql);
}

// Ambil data jadwal
$result = $conn->query("SELECT * FROM jadwal");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Jadwal Pelajaran</title>
    <link rel="stylesheet" href="jadwal.css">
</head>
<body>
    <h2>Jadwal Pelajaran</h2>
    <form method="POST">
        Hari: <input type="text" name="hari" required>
        Mata Pelajaran: <input type="text" name="mata_pelajaran" required>
        Jam Mulai: <input type="time" name="jam_mulai" required>
        Jam Selesai: <input type="time" name="jam_selesai" required>
        Guru: <input type="text" name="guru" required>
        <button type="submit" name="tambah">Tambah</button>
    </form>
    
    <table border="1">
        <tr>
            <th>Hari</th>
            <th>Mata Pelajaran</th>
            <th>Jam Mulai</th>
            <th>Jam Selesai</th>
            <th>Guru</th>
            <th>Aksi</th>
        </tr>
        <?php while ($row = $result->fetch_assoc()) { ?>
        <tr>
            <td><?= $row['hari'] ?></td>
            <td><?= $row['mata_pelajaran'] ?></td>
            <td><?= $row['jam_mulai'] ?></td>
            <td><?= $row['jam_selesai'] ?></td>
            <td><?= $row['guru'] ?></td>
            <td><a href="?hapus=<?= $row['no'] ?>">Hapus</a>
            <a href="?edit=<?= $row['no'] ?>">Edit</a></td>
        </tr>
        <?php } ?>
    </table>
</body>
</html>
<?php $conn->close(); ?>
